#!/bin/bash
echo "1. Affichez le nombre d'attributs par document ainsi que l'attribut name. Combien y a-t-il d'attribut par document ? N'affichez que les 12 premières lignes avec la commande head (notebook #2)." > /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
cat people.json | jq .[] | jq '{name: .name, attribute_count:length}' | head -n 12 >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Commande : <cat people.json | jq .[] | jq '{name: .name, attribute_count:length}' | head -n 12>" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Réponse : il y a 17 attributs par document et l'attribut 'name' indique le nom et le prénom des personnages." >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo -e "\n---------------------------------\n" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "2. Combien y a-t-il de valeur "unknown" pour l'attribut "birth_year" ? Utilisez la commande tail afin d'isoler la réponse." >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
cat people.json | jq '[.[] | select(.birth_year == "unknown")] | length' | tail -n 1 >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Commande : <cat people.json | jq '[.[] | select(.birth_year == "unknown")] | length' | tail -n 1>" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Réponse : il y a 42 "birth_year" qui sont "unknow". La commande parcourt les documents et sélectionne ceux dont la valeur est strictement égale à 'unknow', enfin elle compte les fois où cette valeur a été sélectionnée." >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo -e "\n---------------------------------\n" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "3. Affichez la date de création de chaque personnage et son nom. La date de création doit être de cette forme : l'année, le mois et le jour. N'affichez que les 10 premières lignes. (Pas de Réponse attendue)" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
cat people.json | jq '.[] | {name: .name, created: (.created | split("T")[0])}' | head -n 10 >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Commande : <cat people.json | jq '.[] | {name: .name, created: (.created | split("T")[0])}' | head -n 10>" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo -e "\n---------------------------------\n" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "4. Certains personnages sont nés en même temps. Retrouvez toutes les pairs d'ids (2 ids) des personnages nés en même temps." >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
cat people.json | jq -r 'group_by(.birth_year) | map({birth_year: .[0].birth_year, count:length}) | map(select(.count == 2))' >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Commande : <cat people.json | jq -r 'group_by(.birth_year) | map({birth_year: .[0].birth_year, count:length}) | map(select(.count == 2))'>" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Réponse : les personnages : 19BBY, 41.9BBY, 52BBY, 72BBY, 82BBY et 92BBY. La commande les dates d'anniversaire dans un talbeau, puis compte l'apparition de chacune. Enfin elle sélectionne celle qui sont apparue deux fois." >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo -e "\n---------------------------------\n" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "5. Renvoyez le numéro du premier film (de la liste) dans lequel chaque personnage a été vu suivi du nom du personnage. N'affichez que les 10 premières lignes. (Pas de Réponse attendue)" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
cat people.json | jq -r '.[] | "\(.name) \(.films[0][-2:-1])"' | head -n 10 >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "Commande : <cat people.json | jq -r '.[] | '\(.name) \(.films[0][-2:-1])'' | head -n 10>" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo -e "\n---------------------------------\n" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo -e "\n----------------BONUS----------------\n" >> /home/ubuntu/exam_GAUTHIER/exam_jq/res_jq.txt
echo "6. Supprimez les documents lorsque l'attribut height n'est pas un nombre." 
cat people.json | jq '[.[] | select(test("^[0-9]+$"; "height") | not) | del(.height)]'
echo -e "\n---------------------------------\n"
# Question 7 : Transformer l'attribut height en nombre 
jq '[.[] | select(test("^[0-9]+$"; "height")) | .height |= tonumber]' people.json > home/ubuntu/exam_GAUTHIER/exam_jq/bonus/people_7.json
echo -e "\n---------------------------------\n"
# Question 8 : Ne renvoyez que les personnages dont la taille est entre 156 et 171 
jq '[.[] | select(.height | tonumber >= 156 and .height | tonumber <= 171)]' home/ubuntu/exam_GAUTHIER/exam_jq/bonus/people_7.json > home/ubuntu/exam_GAUTHIER/exam_jq/bonus/people_8.json
echo -e "\n---------------------------------\n"
# Question 9 : Renvoyez le plus petit individu de people_7.json et affichez cette phrase en une seule commande : "<nom_du_personnage> is <taille> tall" 
jq -r 'min_by(.height) | "\(.name) is \(.height) tall"' home/ubuntu/exam_GAUTHIER/exam_jq/bonus/people_7.json > home/ubuntu/exam_GAUTHIER/exam_jq/bonus/people_9.txt
echo -e "\n---------------------------------\n"