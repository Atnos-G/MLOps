#!/bin/bash

# Fonction pour récupérer les chiffres de vente
function sales_recoveries {
    card=$1
    url="http://0.0.0.0:5000/$card"
    sales=$(curl -s "$url")
    echo "$card:$sales"
}

# Liste des cartes graphiques
cards=(rtx3060 rtx3070 rtx3080 rtx3090 rx6700)

# Ajouter la date actuelle au fichier de sortie
echo "$(date)" >> /home/ubuntu/exam_GAUTHIER/exam_bash/sales.txt

# Boucle pour parcourir les cartes graphiques
for card in "${cards[@]}"; do
    sales_recoveries "$card" >> /home/ubuntu/exam_GAUTHIER/exam_bash/sales.txt
done
