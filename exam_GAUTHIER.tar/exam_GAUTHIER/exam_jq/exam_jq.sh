#!/bin/bash
# Question 1.
echo "1. Affichez le nombre d'attributs par document ainsi que l'attribut name. Combien y a-t-il d'attribut par document ? N'affichez que les 12 premières lignes avec la commande head (notebook #2)."
cat people.json | jq '.[] | {name: .name, attribute_count: length}' | head -n 12 ./exam_jq.sh > res_jq.txt
echo "Commande : <cat people.json | jq '.[] | {name: .name, attribute_count: length}' | head -n 12 ./exam_jq.sh > res_jq.txt>"
echo "Réponse : réponse de la question 1 si demandé"
echo -e "\n---------------------------------\n"
# Question 2.
echo "2. Combien y a-t-il de valeur "unknown" pour l'attribut "birth_year" ? Utilisez la commande tail afin d'isoler la réponse."
cat people.json | jq '[.[] | select(.birth_year == "unknown")] | length' ./exam_jq.sh > res_jq.txt
echo "Commande : <cat people.json | jq '[.[] | select(.birth_year == "unknown")] | length' ./exam_jq.sh > res_jq.txt>"
echo "Réponse : réponse de la question 2 si demandé"
echo -e "\n---------------------------------\n"
# Question 3.
echo "3. Affichez la date de création de chaque personnage et son nom. La date de création doit être de cette forme : l'année, le mois et le jour. N'affichez que les 10 premières lignes. (Pas de Réponse attendue)"
cat people.json | jq '.[] | {name: .name, created: (.created | split("T")[0])}' | head n- 10 ./exam_jq.sh > res_jq.txt
echo "Commande : <cat people.json | jq '.[] | {name: .name, created: (.created | split("T")[0])}' | head n- 10 ./exam_jq.sh > res_jq.txt>"
echo -e "\n---------------------------------\n"
# Question 4.
echo "4. Certains personnages sont nés en même temps. Retrouvez toutes les pairs d'ids (2 ids) des personnages nés en même temps."
cat people.json | jq '[ .[] | {id: .url, birth_year: .birth_year} ] | group_by(.birth_year) | .[] | select(length > 1) | { birth_year: .[0].birth_year, pairs: [.[].id] | combinations | map([.[0], .[1]]) }' ./exam_jq.sh > res_jq.txt
echo "Commande : <cat people.json | jq '[ .[] | {id: .url, birth_year: .birth_year} ] | group_by(.birth_year) | .[] | select(length > 1) | { birth_year: .[0].birth_year, pairs: [.[].id] | combinations | map([.[0], .[1]]) }' ./exam_jq.sh > res_jq.txt>"
echo "Réponse : réponse de la question 4 si demandé"
echo -e "\n---------------------------------\n"
# Question 5.
echo "5. Renvoyez le numéro du premier film (de la liste) dans lequel chaque personnage a été vu suivi du nom du personnage. N'affichez que les 10 premières lignes. (Pas de Réponse attendue)"
cat people.json | jq '.[] | {films: .films, name: .name} | head -n 10 ./exam_jq.sh > res_jq.txt
echo "Commande : <cat people.json | jq '.[] | {films: .films, name: .name} | head -n 10 ./exam_jq.sh > res_jq.txt>"
echo -e "\n---------------------------------\n"
echo -e "\n----------------BONUS----------------\n"
# Question 6.
echo "6. Supprimez les documents lorsque l'attribut height n'est pas un nombre."
cat people.json | jq '[.[] | select(test("^[0-9]+$"; "height") | not) | del(.height)]'
echo -e "\n---------------------------------\n"
# Question 7 : Transformer l'attribut height en nombre
jq '[.[] | select(test("^[0-9]+$"; "height")) | .height |= tonumber]' people.json > exam_jq/bonus/people_7.json
echo -e "\n---------------------------------\n"
# Question 8 : Ne renvoyez que les personnages dont la taille est entre 156 et 171
jq '[.[] | select(.height | tonumber >= 156 and .height | tonumber <= 171)]' exam_jq/bonus/people_7.json > exam_jq/bonus/people_8.json
echo -e "\n---------------------------------\n"
# Question 9 : Renvoyez le plus petit individu de people_7.json et affichez cette phrase en une seule commande : "<nom_du_personnage> is <taille> tall"
jq -r 'min_by(.height) | "\(.name) is \(.height) tall"' exam_jq/bonus/people_7.json > exam_jq/bonus/people_9.txt
echo -e "\n---------------------------------\n"

